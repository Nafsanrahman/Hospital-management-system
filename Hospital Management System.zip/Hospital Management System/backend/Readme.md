
**Admin Login Details**

* Email   : admin@mail.com 

* Password: Password@123

**Doctor Login Details**

* ID      : YDS7L

* Password: password
